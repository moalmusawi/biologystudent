# لا حياة بلا أحياء

موقع متخصص لمادة الأحياء، مصمم ليكون رفيقك الأول في رحلتك الدراسية. نوفر لك كل ما تحتاجه من كتب، ملخصات، واختبارات لمساعدتك على التفوق وتبسيط المفاهيم العلمية بأسلوب شيق وجذاب.

## How to Run

This project is set up to run directly in the browser. No build step is required.

1.  Clone the repository.
2.  Open the `index.html` file in a modern web browser.

The application uses import maps to load dependencies from a CDN.
