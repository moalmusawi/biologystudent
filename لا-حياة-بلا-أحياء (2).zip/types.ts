
export interface NavLink {
  label: string;
  path: string;
}
